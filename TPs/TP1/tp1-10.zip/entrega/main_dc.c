#include <stdio.h>
#include <stdlib.h>
#include "dc.h"

int main(int argc, char *argv[]) {
	
    return dc_procesar_entrada();
    
}
