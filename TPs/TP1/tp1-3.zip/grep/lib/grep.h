#ifndef GREP_H
#define GREP_H

#include <stdbool.h>

bool grep(char* keyword, int lineas, char* archivo);

#endif // GREP_H
