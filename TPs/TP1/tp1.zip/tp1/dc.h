#ifndef DC_H
#define DC_H

int dc_procesar_entrada();

#endif // DC_H
